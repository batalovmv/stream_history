import { Button as MButton, type ButtonProps } from '@mantine/core'
export default function Button(props: ButtonProps) { return <MButton {...props} /> }